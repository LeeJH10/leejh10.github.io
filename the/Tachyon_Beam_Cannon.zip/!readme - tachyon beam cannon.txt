https://chiptuneswin.bandcamp.com/album/chiptunes-win-volume-6

Chiptunes = WIN: Volume 6 exclusive.

Version 4.9.5 (specifically) is recommended.
Attempting to playback the save on a DMG will result in choking.

Load the kits into their respective slots with LSDPatcher v1.1.3 to playback the file correctly. You may need to fill slots 22 & 26-39 with miscellaneous kits (hint: just reuse one of the same kits to fill the space).

Enjoy. :)

~aqx