https://chiptuneswin.bandcamp.com/album/chiptunes-win-volume-5

Chiptunes = WIN: Volume 5 exclusive.

Version 4.7.3+ is recommended.
DMG friendly, provided you're using a version higher than 4.

Load the kits into their respective slots with LSDPatcher to playback the file correctly. You may need to fill slots 24-34 & 36-49 with miscellaneous kits (hint: just reuse one of the same kits to fill the space).

Enjoy. :)

~aqx