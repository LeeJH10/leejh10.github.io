var data = [];
var linkColor1;
var linkColor2;

//match, background, foreground
var bindings;

$(document).ready(function ()
{
    $('div.sluts font').each(function ()
    {
        $(this).wrap("<div></div>");
    });

    shuffle();

    bindings = [
        //entry top title background
        //".entry", "rgb(12, 9, 20)", "",
        ".entry", data[0], "",

        //results side thing
        "div.sluts font", "", data[8],

        //points counter also stars
        //"table#results tbody tr td b", "", "rgb(89, 195, 155)",
        "table#results tbody tr td b", "", data[15],

        //second column counter??? idk what this is
        //"c#FFAAAA", "", "rgb(231, 160, 123)",
        "c#FFAAAA", "", data[10],

        //third column counter w/e it is
        //"c#AAAAFF", "", "rgb(152, 133, 210)",
        "c#AAAAFF", "", data[9],

        //sub-third place place backgrounds
        //"b#777777", "rgb(68, 60, 94)", "rgb(152, 133, 210)",
        "b#777777", data[1], data[5],
        //"b#9999BB", "rgb(68, 60, 94)", "rgb(152, 133, 210)",
        "b#9999BB", data[1], data[5],

        //sub 5 stars
        "c#DDDD55", "", data[6],
        "c#DDDD77", "", data[6],

    ]

    updateColors();

      $("body").fadeIn(1000);
});

function updateColors()
{
    $('td').each(function ()
    {
        if ($(this).parent().attr("class") != "entry")
            setColorBG(this, data[0], data[5]);
        else setColorBG(this, data[2], data[5]);
    });

    var style = $('<style>a { color:' + linkColor1 + ' !important; } a:hover { color:' + linkColor2 + ' !important; }</style>');
    $('html > head').append(style);

    console.log(linkColor1);

    var count = 0;
    for (i = 0; i < bindings.length; i += 3)
    {
        var match = bindings[i];
        //match foreground color
        if (match[0] === 'c')
        {
            if (match[1] === '#')
            {
                var colorHex = match.substring(1, match.length).toLowerCase();

                $('*').each(function ()
                {
                    if (rgb2hex($(this).css("color")).toLowerCase() === colorHex ||
                        $(this).css("color").toLowerCase() === colorHex)
                    {
                        setColorBG(this, bindings[i + 1], bindings[i + 2]);
                    }
                });
            }
        }
        //match background color
        else if (match[0] === 'b')
        {
            if (match[1] === '#')
            {
                var colorHex = match.substring(1, match.length).toLowerCase();
                $('*').each(function ()
                {
                    if (rgb2hex($(this).css("background-color")).toLowerCase() === colorHex ||
                        $(this).css("background-color").toLowerCase() === colorHex)
                    {
                        setColorBG(this, bindings[i + 1], bindings[i + 2]);
                    }
                });
            }
        }
        //match tag
        else
        {
            $(match).each(function ()
            {
                setColorBG(match, bindings[i + 1], bindings[i + 2]);
            });
        }
    }


}

function setColorBG(match, bg, fg)
{
    if (bg != "")
    {
        $(match).css("background-color", bg);
    }
    if (fg != "")
    {
        $(match).css("color", fg);
    }
}

function modifyStyleRule(selectorText, value) {
  var sheets = document.styleSheets;
  var sheet, rules, rule;
  var i, j, k, l;

  for (i=0, iLen=sheets.length; i<iLen; i++) {
    sheet = sheets[i];

    // W3C model
    if (sheet.cssRules) {
      rules = sheet.cssRules;

      for (j=0, jLen=rules.length; j<jLen; j++) {
        rule = rules[j];

        if (rule.selectorText == selectorText) {
          removeRule(sheet, rule);
          addRule(sheet, selectorText, value);
        }
      }

    // IE model
    } else if (sheet.rules) {
      rules = sheet.rules;

      for (k=0, kLen=rules.length; k<kLen; k++) {
        rule = rules[k];

        // An alternative is to just modify rule.style.cssText,
        // but this way keeps it consistent with W3C model
        if (rule.selectorText == selectorText) {
          removeRule(sheet, rule);
          addRule(sheet, selectorText, value);

          // Alternative
          // rule.style.cssText = value;
        }
      }
    }
  }
}

//Function to convert hex format to a rgb color
function rgb2hex(rgb)
{
    rgb = rgb.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i);
    return (rgb && rgb.length === 4) ? "#" +
        ("0" + parseInt(rgb[1], 10).toString(16)).slice(-2) +
        ("0" + parseInt(rgb[2], 10).toString(16)).slice(-2) +
        ("0" + parseInt(rgb[3], 10).toString(16)).slice(-2) : '';
}

$('button').click(function ()
{
    var hex = rgb2hex($('input').val());
    $('.result').html(hex);
});

function generateSeed()
{
    var seed = "";
    for (var i = 0; i <= 5; i++)
    {
        seed += _.random(0, 9);
    }
    return seed;
}

function shuffle()
{
    // 6 hues to pick from
    var h = _.random(0, 360);
    var H = _.map([0, 60, 120, 180, 240, 300], function (offset)
    {
        return (h + offset) % 360;
    });
    // 8 shades of low-saturated color
    var backS = _.random(5, 40);
    var darkL = _.random(3, 5);
    var rangeL = 90 - darkL;
    for (var i = 0; i <= 7; i++)
    {
        data.push($.husl.toHex(H[0], backS, darkL + rangeL * Math.pow(i / 7, 1.5)));
    }
    // 8 Random shades
    var minS = _.random(30, 70);
    var maxS = minS + 30;
    var minL = _.random(50, 70);
    var maxL = minL + 20;
    for (var j = 0; j <= 7; j++)
    {
        var h = H[_.random(0, 5)];
        var s = _.random(minS, maxS);
        var l = _.random(minL, maxL);
        data.push($.husl.toHex(h, s, l));
    }

    var hue1 = _.random(0, 360);
    linkColor1 = $.husl.toHex(hue1, 50, 60);
    linkColor2 = $.husl.toHex(hue1 + 30, 80, 80);

    // Update colors and download links
    var params = [];
    for (var k = 0; k <= 15; k++)
    {
        var color = data[k];
        var key = 'base0' + k.toString(16).toUpperCase();
        $('.' + key).css('color', color);
        $('.' + key + '-background').css('background-color', color);
        params.push(key + '=' + color.substring(1));
    }
    params = params.join('&');
    $('body').css('background-color', $.husl.toHex(H[0], backS, 3));
    $('body').css('background-color', '#000000');
    $('#shuffle').css('background-color', $.husl.toHex(H[0], backS, 20));
};